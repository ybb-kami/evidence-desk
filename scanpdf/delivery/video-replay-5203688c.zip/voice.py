"""Generate chapter narration and exact edit points using the verified Kokoro release."""
import argparse
import hashlib
import json
from pathlib import Path
import wave

import numpy as np
import sherpa_onnx as sherpa

ROOT = Path(__file__).resolve().parent
ARCHIVE_SHA = '72c347230107ef8a31098ec4d468a605244beef5f1ed00db97efa13518800653'
LICENSE_SHA = 'cfc7749b96f63bd31c3c42b5c471bf756814053e847c10f3eb003417bc523d30'


def digest(path):
    with path.open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()


def run(model, archive, out, speed, only):
    if digest(archive) != ARCHIVE_SHA or digest(model / 'LICENSE') != LICENSE_SHA:
        raise ValueError('Kokoro distribution or license does not match the documented release.')
    tts_model = sherpa.OfflineTtsKokoroModelConfig(
        model=str(model / 'model.int8.onnx'), voices=str(model / 'voices.bin'),
        tokens=str(model / 'tokens.txt'), lexicon=str(model / 'lexicon-zh.txt'),
        dict_dir=str(model / 'dict'), data_dir=str(model / 'espeak-ng-data'), lang='zh')
    tts = sherpa.OfflineTts(sherpa.OfflineTtsConfig(
        model=sherpa.OfflineTtsModelConfig(kokoro=tts_model, num_threads=2)))
    out.mkdir(parents=True, exist_ok=True)
    manifest = []
    for scene in json.loads((ROOT / 'narration.json').read_text()):
        if only and scene['id'] not in only:
            continue
        path = out / (scene['id'] + '.wav')
        elapsed = 0.0
        cues = []
        with wave.open(str(path), 'wb') as wav:
            wav.setparams((1, 2, tts.sample_rate, 0, 'NONE', ''))
            for line in scene['lines']:
                samples = np.asarray(tts.generate(line.replace('PDF', '文档'), sid=47, speed=speed).samples)
                if not len(samples):
                    raise ValueError(f'Empty voice cue for {scene["id"]}')
                pcm = (samples.clip(-1, 1) * 31000).astype('<i2')
                wav.writeframes(pcm.tobytes())
                cues.append({'start': elapsed, 'end': elapsed + len(pcm) / tts.sample_rate, 'text': line})
                gap = int(tts.sample_rate * .24)
                wav.writeframes(bytes(gap * 2))
                elapsed += (len(pcm) + gap) / tts.sample_rate
        manifest.append({'id': scene['id'], 'title': scene['title'], 'seconds': elapsed, 'cues': cues})
        print(scene['id'], f'{elapsed:.2f}s', flush=True)
    (out / 'voice-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model', type=Path, required=True)
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--speed', type=float, default=1.06)
    parser.add_argument('--only', action='append', help='Generate a named chapter for a limited rehearsal')
    args = parser.parse_args()
    run(args.model, args.archive, args.out, args.speed, args.only)
