"""Record chapter 08 on the approved frozen build, using the app's terminology control."""
import argparse
import json
import os
from pathlib import Path
import re
import sys
import tempfile

from playwright.sync_api import expect, sync_playwright
from replay import launch, Scene, upload, NATIVE_NAME, NATIVE_SHA, VIEW

args = argparse.ArgumentParser(description=__doc__)
args.add_argument('--frozen', type=Path, required=True)
args.add_argument('--pdf-dir', type=Path, required=True)
args.add_argument('--translation-models', type=Path, required=True)
args.add_argument('--runtime-path', action='append', default=[])
args.add_argument('--out', type=Path, required=True)
args.add_argument('--chromium', default='/usr/bin/chromium')
args = args.parse_args()
metadata = json.loads((args.frozen / 'replay-proof.json').read_text())
REVISION = metadata['archived_revision']
REPO = args.frozen / 'source'
CORPUS = args.pdf_dir
out = args.out
out.mkdir(exist_ok=False)
env = {key: value for key, value in os.environ.items() if key not in ('DEEPSEEK_API_KEY', 'EVIDENCE_LOCAL_QA_URL', 'EVIDENCE_LOCAL_QA_MODEL')}
env.update(EVIDENCE_TRANSLATION_MODELS=str(args.translation_models),
           PYTHONPATH=os.pathsep.join(args.runtime_path))
with tempfile.TemporaryDirectory(dir=out) as workspace:
    with launch(REPO, Path(workspace) / 'native', env, sys.executable, 'native', out) as origin, \
            sync_playwright() as playwright:
        doc = upload(origin, CORPUS / NATIVE_NAME)
        assert doc == NATIVE_SHA
        with playwright.chromium.launch(executable_path=args.chromium, args=['--no-sandbox','--disable-dev-shm-usage']) as browser:
            camera = browser.new_context(viewport=VIEW, record_video_dir=str(Path(workspace) / 'camera'),
                                         record_video_size=VIEW)
            page = camera.new_page()
            scene = Scene(page, 36, 1)
            try:
                scene.goto(origin, f'/translation?doc={doc}&page=1')
                source = page.locator('#source-pane .source-card').filter(has_text='We propose a new').first
                expect(source).to_be_visible()
                anchor = source.get_attribute('data-anchor')
                target = page.locator(f'#translation-pane [data-anchor="{anchor}"]')
                terms = page.get_by_text('设置需保留原文的术语', exact=True)
                scene.hold(.12)
                terms.click()
                page.locator('#terms').fill('Transformer\nWMT\nensembles')
                page.locator('#applyTerms').click()
                expect(page.locator('#status')).to_contain_text('已应用 3 个术语')
                scene.event('Preserved Transformer, WMT and ensembles through the actual terminology setting')
                terms.click()
                source.get_by_role('button', name='定位译文').click()
                expect(target).to_be_focused()
                scene.hold(.20)
                with page.expect_response(lambda r:r.url.endswith('/api/bilingual/translate'), timeout=90_000) as response:
                    source.locator('.run-segment').click()
                assert response.value.ok
                expect(page.locator('#status')).to_contain_text('本次已处理 1 段', timeout=90_000)
                translation = target.locator('.translated').inner_text()
                assert all(term in translation for term in ('Transformer', 'WMT', 'ensembles'))
                assert len(re.findall('[\u3400-\u9fff]', translation)) >= 35, translation
                scene.event('Finished local OPUS-MT translation and retained the term')
                scene.hold(.62)
                pane = page.locator('#source-pane')
                initial = pane.evaluate('pane => pane.scrollTop')
                pane.hover()
                page.mouse.wheel(0, 184)
                page.wait_for_function('''initial => {
                  const l = document.querySelector('#source-pane');
                  const r = document.querySelector('#translation-pane');
                  const a = l.querySelector('.current-passage');
                  const b = r.querySelector('.current-passage');
                  return l.scrollTop > initial && a && b && a.dataset.anchor === b.dataset.anchor;
                }''', arg=initial)
                scene.event('Mouse wheel moved the source pane while the aligned paragraph remained paired')
                scene.hold(.75)
                target.get_by_role('button', name='定位原文').click()
                expect(source).to_be_focused()
                scene.hold(1)
                page.screenshot(path=out / '08-bilingual.png')
                report = {'revision': REVISION, 'source_sha256': doc, 'page': 1, 'anchor': anchor,
                          'live_translation_request': True, 'protected_term': 'Transformer',
                          'protected_terms': ['Transformer', 'WMT', 'ensembles'],
                          'translation': translation, 'actions': scene.events}
                (out / 'proof.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
            finally:
                video = page.video
                camera.close()
                video.save_as(str(out / '08-bilingual.webm'))
print((out / 'proof.json').read_text())
