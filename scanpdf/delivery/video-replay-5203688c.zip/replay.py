"""Rehearse or record actual Evidence Desk workflows in isolated loopback libraries."""
import argparse
from contextlib import contextmanager
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tarfile
import tempfile
import time
from urllib.parse import quote, urljoin, urlsplit
from urllib.request import ProxyHandler, Request, build_opener

from playwright.sync_api import expect, sync_playwright

from create_assets import REPORT, TRIALS, create

HERE = Path(__file__).resolve().parent
SCAN_NAME = '1706.03762v1_img.pdf'
NATIVE_NAME = '1706.03762v1.pdf'
SCAN_SHA = '64094fe169dd4ff454f579e9f197298df1c118c24b71b1f1ca8bb218c9e4801d'
NATIVE_SHA = '0a9bff1be3575cf9fe26a4a3d3a9175bc791ecec90de8b9deba4cff75d2b9476'
POSITIVE = 'How many waterproof recorders were installed on the eastern boardwalk?'
GAP = 'What was the invoice price in dollars for one waterproof recorder installed on the eastern boardwalk?'
NATIVE_CELL = 'In Table 2.4, what is the F1 of West?'
OCR_CELL = '扫描版表2中big模型的英德、英法BLEU各是多少？'
VIEW = {'width': 1920, 'height': 1080}
PLANNED_SECONDS = (32, 32, 42, 34, 34, 34, 34, 36, 47, 36, 34)
HTTP = build_opener(ProxyHandler({}))


def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args], text=True).strip()


def read_api(origin, path, data=None, mime='application/json'):
    if isinstance(data, dict):
        data = json.dumps(data).encode()
    request = Request(origin + path, data=data, headers={'Content-Type': mime} if data is not None else {})
    with HTTP.open(request, timeout=120) as response:
        return json.load(response)


def upload(origin, path):
    raw = path.read_bytes()
    doc = read_api(origin, '/api/import?name=' + quote(path.name), raw, 'application/pdf')['doc']
    assert doc['id'] == hashlib.sha256(raw).hexdigest(), path
    return doc['id']


@contextmanager
def launch(repo, data, env, python, name, out):
    with (out / f'{name}-workbench.stderr').open('w') as errors:
        process = subprocess.Popen([python, str(repo / 'scanpdf/workbench.py'), '--port', '0', '--data', str(data)],
                                   stdout=subprocess.PIPE, stderr=errors, text=True, env=env)
        try:
            origin = process.stdout.readline().strip()
            if urlsplit(origin).hostname != '127.0.0.1':
                raise RuntimeError(f'Workbench {name} did not report a loopback address')
            assert isinstance(read_api(origin, '/api/library')['docs'], list)
            yield origin
        finally:
            process.terminate()
            try:
                process.wait(timeout=8)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=8)
            process.stdout.close()


class Scene:
    def __init__(self, page, seconds, pacing):
        self.page = page
        self.began = time.monotonic()
        self.duration = seconds * pacing
        self.events = []

    def hold(self, fraction):
        delay = self.began + self.duration * fraction - time.monotonic()
        if delay > 0:
            self.page.wait_for_timeout(delay * 1000)

    def event(self, description):
        self.events.append({'seconds': round(time.monotonic() - self.began, 2), 'action': description})

    def goto(self, origin, path='/'):
        self.page.goto(origin + path, wait_until='domcontentloaded')

    def center(self, locator):
        locator.evaluate("element => element.scrollIntoView({behavior:'instant', block:'center'})")

    def click_source(self, locator):
        # Open the actual citation with the app's handler. Switch the recorded viewport to its exact URL.
        target = urljoin(self.page.url, locator.get_attribute('href'))
        if locator.get_attribute('target') == '_blank':
            with self.page.expect_popup() as captured:
                locator.click()
            pop = captured.value
            pop.wait_for_load_state('domcontentloaded')
            assert pop.url == target
            pop.close()
        self.page.goto(target, wait_until='domcontentloaded')
        return target


def followup(scene, origin, document, question):
    page = scene.page
    scene.goto(origin, '/followup')
    picker = page.locator('#doc')
    expect(picker.locator(f'option[value="{document}"]')).to_have_count(1)
    picker.select_option(value=document)
    page.locator('#question').fill(question)
    scene.hold(.18)
    scene.event('Submit question in the browser')
    with page.expect_response(lambda r: r.url.endswith('/api/followup'), timeout=120_000) as response:
        page.locator('#send').click()
    body = response.value.json()
    if not response.value.ok:
        raise RuntimeError(body.get('error'))
    turn = page.locator('#history > section').last
    expect(turn).to_be_visible()
    scene.center(turn.locator('h2'))
    scene.event('Live response and source links shown')
    return body, turn


def shots(main, graph, docs, out, proof, capture):
    def intro(scene):
        scene.goto(main)
        expect(scene.page.get_by_role('heading', name='从检索回到原文')).to_be_visible()
        scene.hold(.45)
        scene.center(scene.page.locator('#library-title'))

    def new_upload(scene):
        page = scene.page
        scene.goto(main)
        count = page.locator('#library-count')
        expect(count).to_contain_text('2')
        scene.center(page.locator('#choose'))
        scene.hold(.18)
        with page.expect_file_chooser() as dialog:
            page.locator('#choose').click()
        with page.expect_response(lambda r: '/api/import?name=' in r.url) as response:
            dialog.value.set_files(REPORT)
        assert response.value.ok, response.value.status
        expect(page.locator('#import-log')).to_contain_text('已导入')
        digest = hashlib.sha256(REPORT.read_bytes()).hexdigest()
        imported, = [doc for doc in read_api(main, '/api/library')['docs'] if doc['id'] == digest]
        assert imported['name'] == REPORT.name and imported['pages'] == 2, imported
        docs['new'] = imported['id']
        proof['new_upload'] = imported
        scene.event('New PDF was dynamically imported from the chooser')
        scene.center(page.locator('#import-log'))

    def new_question(scene):
        body, turn = followup(scene, main, docs['new'], POSITIVE)
        assert re.search(r'\b17\b', body.get('answer') or '') and body['answer_method'] in ('local_extractive', 'local_cited_draft'), body
        proof['positive'] = {key: body[key] for key in ('answer', 'answer_method', 'retrieval', 'reader', 'generation') if key in body}
        detail = turn.get_by_text('查看本机抽取候选及原句', exact=True)
        if detail.count():
            scene.hold(.57)
            detail.click()
        locator = turn.locator('a[href*="/source?"][href*="start="]').first
        expect(locator).to_be_visible()
        docs['positive_link'] = locator.get_attribute('href')
        scene.center(locator)

    def source_gap(scene):
        scene.goto(main, docs['positive_link'])
        expect(scene.page.locator('#overlay .selected').first).to_be_visible()
        expect(scene.page.locator('#excerpt')).to_contain_text('17')
        scene.event('Actual original PDF page and precise highlight shown')
        scene.hold(.48)
        body, turn = followup(scene, main, docs['new'], GAP)
        assert not body.get('answer') and body.get('gap'), body
        proof['missing'] = {'answer': body['answer'], 'gap': body['gap'], 'retrieval': body.get('retrieval')}
        expect(turn).to_contain_text(body['gap'])

    def native_table(scene):
        body, turn = followup(scene, main, docs['new'], NATIVE_CELL)
        assert body['answer_method'] == 'native_table' and body['table_cells'][0]['value'] == '84.3', body
        proof['native'] = {'answer': body['answer'], 'cells': body['table_cells']}
        scene.hold(.44)
        link = turn.get_by_role('link', name=re.compile('West.*物理页 2'))
        scene.click_source(link)
        expect(scene.page.locator('#overlay .region').first).to_be_visible()
        expect(scene.page.locator('#excerpt')).to_contain_text('84.3')
        scene.event('Opened native PDF page 2 and verified the cell highlight')

    def ocr(scene):
        page = scene.page
        bare = read_api(main, f'/api/scan/{docs["scan"]}?page=8')
        assert bare['page'] is None and 8 in bare['pending_pages'], 'OCR scene requires a fresh uncached page'
        scene.goto(main, f'/scan?id={docs["scan"]}&page=8')
        expect(page.locator('#scan')).to_be_enabled()
        expect(page.locator('#preview')).to_be_visible()
        scene.hold(.23)
        started = time.monotonic()
        with page.expect_response(lambda r: r.url.endswith('/api/scan'), timeout=120_000) as recorded:
            page.locator('#scan').click()
        received = recorded.value.json()
        assert recorded.value.ok and received['page']['physical_page'] == 8
        assert 8 not in received['pending_pages']
        tables = [region for region in received['page']['regions'] if region['type'] == 'table']
        assert tables
        proof['ocr'] = {'was_cached': False, 'physical_page': 8, 'tables': len(tables),
                        'seconds': round(time.monotonic() - started, 3)}
        scene.event('The scan worker completed a previously uncached page')
        page.locator('#query').fill('表格')
        page.locator('.result').first.click()
        expect(page.locator('#mark')).to_be_visible()
        scene.center(page.locator('#detail'))

    def ocr_citation(scene):
        body, turn = followup(scene, main, docs['scan'], OCR_CELL)
        assert body['answer_method'] == 'scan_table' and {cell['value'] for cell in body['table_cells']} == {'28.4', '41.0'}, body
        proof['ocr_answer'] = {'using_cache_from_previous_scene': True, 'answer': body['answer'], 'cells': body['table_cells']}
        scene.hold(.49)
        target = turn.get_by_role('link', name=re.compile('打开物理页 8 的单元格')).first
        scene.click_source(target)
        expect(scene.page.locator('#mark')).to_be_visible()
        expect(scene.page.locator('#table-cell')).to_have_value(f"{body['table_cells'][0]['row']},{body['table_cells'][0]['column']}")
        scene.center(scene.page.locator('#mark'))
        scene.event('Opened the actual cited OCR cell and matching coordinate')

    def bilingual(scene):
        page = scene.page
        scene.goto(main, f'/translation?doc={docs["native"]}&page=1')
        source = page.locator('#source-pane .source-card').filter(has_text='We propose a new').first
        expect(source).to_be_visible()
        anchor = source.get_attribute('data-anchor')
        translated = page.locator(f'#translation-pane [data-anchor="{anchor}"]')
        source.get_by_role('button', name='定位译文').click()
        expect(translated).to_be_focused()
        scene.hold(.24)
        with page.expect_response(lambda r: r.url.endswith('/api/bilingual/translate'), timeout=90_000) as response:
            source.locator('.run-segment').click()
        assert response.value.ok
        expect(page.locator('#status')).to_contain_text('本次已处理 1 段', timeout=90_000)
        result = translated.locator('.translated').inner_text()
        assert len(result) >= 60 and len(re.findall(r'[\u3400-\u9fff]', result)) >= 35, result
        proof['bilingual'] = {'page': 1, 'anchor': anchor, 'translation': result,
                              'live_translation_request': True}
        scene.hold(.56)
        page.locator('#source-pane').hover()
        page.mouse.wheel(0, 150)
        page.wait_for_function("""() => {
            const source = document.querySelector('#source-pane .current-passage');
            const translation = document.querySelector('#translation-pane .current-passage');
            return source && translation && source.dataset.anchor === translation.dataset.anchor;
        }""")
        scene.hold(.70)
        translated.get_by_role('button', name='定位原文').click()
        expect(source).to_be_focused()
        scene.event('Original and translation share the same paragraph anchor')

    def synthesis(scene):
        page = scene.page
        scene.goto(graph, '/#citation-graph')
        with page.expect_response(lambda r: r.url.endswith('/api/graph')) as graph_response:
            page.locator('#load-graph').click()
        assert graph_response.value.ok
        expect(page.locator('#graph-canvas svg')).to_be_visible()
        scene.event('Generated the live citation graph for the preloaded collection')
        scene.hold(.13)
        page.get_by_text('选择文献生成综述', exact=True).click()
        expect(page.locator('#papers input')).to_have_count(20)
        scene.hold(.20)
        page.check('#all')
        with page.expect_response(lambda r: r.url.endswith('/api/synthesis'), timeout=120_000) as response:
            page.locator('#local').click()
        body = response.value.json()
        assert response.value.ok and body['works'] == 20 and body['edges'] == 28 and body['abstracts'] == 19
        expect(page.locator('tr[id^="paper-"]')).to_have_count(20)
        proof['synthesis'] = {'preloaded_pdfs': 20, 'works': 20, 'edges': 28, 'abstracts': 19,
                              'future_directions': len(body['follow_ups']),
                              'postdated_text_comparisons': sum(row['checked'] for row in body['follow_ups']),
                              'later_candidates': sum(row['matches'] for row in body['follow_ups'])}
        scene.hold(.43)
        page.get_by_role('link', name='库内引用分组', exact=True).click()
        known = page.get_by_role('link', name=re.compile('BERT:.* → Attention Is All You Need'))
        expect(known).to_be_visible()
        scene.center(known)
        scene.hold(.64)
        known.click()
        expect(page.locator('article:target blockquote')).to_contain_text('Attention')
        scene.hold(.78)
        page.get_by_role('link', name='未来工作与后续证据', exact=True).click()
        direction = page.locator('details[data-direction]').first
        direction.locator('summary').click()
        expect(direction.locator('blockquote').first).to_be_visible()
        scene.event('Live coverage, citation anchor and one future-work direction shown')

    def csv(scene):
        page = scene.page
        scene.goto(main, '/#csv-workbench')
        expect(page.locator('#csv-file')).to_be_visible()
        scene.hold(.12)
        page.locator('#csv-file').set_input_files(TRIALS)
        expect(page.locator('#csv-result')).to_be_visible()
        page.locator('#csv-column').select_option(label='latency_ms')
        page.locator('#csv-value-unit').fill('毫秒')
        page.locator('#csv-row-unit').fill('试次')
        expect(page.locator('#csv-caption')).to_contain_text('有效数值 4 个，空值 1 个')
        scene.center(page.locator('#csv-chart'))
        scene.hold(.56)
        page.locator('#csv-mode').select_option('bar')
        scene.center(page.locator('#csv-caption'))
        scene.hold(.70)
        with page.expect_download() as saved:
            page.locator('#csv-mapping').click()
        destination = out / 'csv-figure-mapping.json'
        saved.value.save_as(destination)
        mapping = json.loads(destination.read_text())
        assert mapping['summary']['used'] == 4 and mapping['summary']['missing'] == 1
        assert mapping['source']['sha256'] == hashlib.sha256(TRIALS.read_bytes()).hexdigest()
        proof['csv'] = {'mode': mapping['mode'], 'source': mapping['source'], 'summary': mapping['summary']}
        scene.event('Generated plot and verified the real data download')

    def close(scene):
        scene.goto(main)
        expect(scene.page.locator('#hero-title')).to_be_visible()
        scene.hold(.40)
        scene.center(scene.page.locator('#library-title'))
        scene.hold(.72)
        scene.goto(main)

    for name, take in zip(('01-intro','02-upload','03-question','04-anchor-gap','05-native-table','06-scan-ocr',
                           '07-scan-cite','08-bilingual','09-synthesis','10-csv','11-close'),
                          (intro,new_upload,new_question,source_gap,native_table,ocr,ocr_citation,bilingual,synthesis,csv,close)):
        capture(name, take)


def run(args):
    args.out.mkdir(parents=True, exist_ok=False)
    proof = {'head': git(args.repo, 'rev-parse', 'HEAD'), 'recording': bool(args.record),
             'checkout_dirty': bool(git(args.repo, 'status', '--short')),
             'model_mode': 'E5 + MobileBERT + OPUS-MT' + (' + loopback generation' if args.local_qa_url else ''),
             'scenes': {}}
    if not 0 < args.pacing <= 1:
        raise ValueError('Use a recording pace greater than zero and at most one.')
    if args.record and not args.expected_sha and args.pacing == 1:
        raise ValueError('A full-paced recording requires the explicitly approved frozen SHA.')
    repo = args.repo
    if args.expected_sha:
        if not re.fullmatch(r'[0-9a-f]{40}', args.expected_sha):
            raise ValueError('Provide a full immutable commit SHA.')
        if git(repo, 'rev-parse', '--verify', f'{args.expected_sha}^{{commit}}') != args.expected_sha:
            raise ValueError('The approved SHA is unavailable in the local repository.')
        repo = args.out / 'source'
        repo.mkdir()
        with subprocess.Popen(['git', '-C', str(args.repo), 'archive', args.expected_sha], stdout=subprocess.PIPE) as archive:
            with tarfile.open(fileobj=archive.stdout, mode='r|*') as snapshot:
                snapshot.extractall(repo, filter='data')
            assert archive.wait() == 0
        proof['archived_revision'] = args.expected_sha
    proof['synthetic_sha256'] = create()
    env = {key: value for key, value in os.environ.items() if key not in ('DEEPSEEK_API_KEY', 'EVIDENCE_LOCAL_QA_URL', 'EVIDENCE_LOCAL_QA_MODEL')}
    env.update(EVIDENCE_QA_READER=str(args.reader_model), EVIDENCE_DENSE_MODEL_DIR=str(args.dense_models),
               EVIDENCE_TRANSLATION_MODELS=str(args.translation_models), PYTHONPATH=os.pathsep.join(args.runtime_path))
    if args.local_qa_url:
        if urlsplit(args.local_qa_url).hostname != '127.0.0.1' or not args.local_qa_model:
            raise ValueError('Use only the approved literal loopback generation endpoint and its model name.')
        env.update(EVIDENCE_LOCAL_QA_URL=args.local_qa_url, EVIDENCE_LOCAL_QA_MODEL=args.local_qa_model)
    voice_lengths = {}
    if args.voice:
        voice_lengths = {chapter['id']: chapter['seconds'] + 2.0 for chapter in json.loads(args.voice.read_text())}
    if str(args.pdf_dir) not in ('', '.'):
        for name, digest in ((SCAN_NAME, SCAN_SHA), (NATIVE_NAME, NATIVE_SHA)):
            assert hashlib.sha256((args.pdf_dir / name).read_bytes()).hexdigest() == digest
    acceptance = repo / 'scanpdf/acceptance'
    sys.path.insert(0, str(acceptance))
    spec = importlib.util.spec_from_file_location('synthesis_twenty_fixture', acceptance / 'synthesis_twenty.py')
    fixture = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(fixture)
    try:
        with tempfile.TemporaryDirectory(prefix='workspace-', dir=args.out) as work:
            work = Path(work)
            with launch(repo, work / 'demo', env, args.python, 'demo', args.out) as main, \
                    launch(repo, work / 'graph', env, args.python, 'graph', args.out) as graph, \
                    sync_playwright() as playwright:
                docs = {'scan': upload(main, args.pdf_dir / SCAN_NAME), 'native': upload(main, args.pdf_dir / NATIVE_NAME)}
                proof['corpus_sha256'] = {name: upload(graph, args.pdf_dir / name) for name in fixture.PAPERS}
                browser = playwright.chromium.launch(executable_path=args.chromium, args=['--no-sandbox', '--disable-dev-shm-usage'])
                try:
                    def record(scene_name, action):
                        options = {'viewport': VIEW}
                        if args.record:
                            options.update(record_video_dir=str(work / 'camera'), record_video_size=VIEW)
                        context = browser.new_context(**options)
                        page = context.new_page()
                        failures = []
                        external = []
                        context.on('request', lambda r: external.append(urlsplit(r.url).hostname)
                                   if urlsplit(r.url).hostname not in (None, '127.0.0.1') else None)
                        page.on('pageerror', lambda error: failures.append(str(error)))
                        planned = PLANNED_SECONDS[int(scene_name[:2]) - 1]
                        scene = Scene(page, max(planned, voice_lengths.get(scene_name, 0)), args.pacing)
                        try:
                            action(scene)
                            scene.hold(1)
                            page.screenshot(path=str(args.out / (scene_name + '.png')))
                            assert not failures and not external, (failures, external)
                            proof['scenes'][scene_name] = {'actions': scene.events}
                        finally:
                            video = page.video
                            context.close()
                            if video:
                                video.save_as(str(args.out / (scene_name + '.webm')))
                        print(scene_name, 'OK', flush=True)
                    shots(main, graph, docs, args.out, proof, record)
                finally:
                    browser.close()
    finally:
        (args.out / 'replay-proof.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--pdf-dir', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--reader-model', type=Path, required=True)
    parser.add_argument('--dense-models', type=Path, required=True)
    parser.add_argument('--translation-models', type=Path, required=True)
    parser.add_argument('--runtime-path', action='append', default=[])
    parser.add_argument('--local-qa-url')
    parser.add_argument('--local-qa-model')
    parser.add_argument('--voice', type=Path)
    parser.add_argument('--expected-sha')
    parser.add_argument('--record', action='store_true')
    parser.add_argument('--pacing', type=float, default=.04)
    parser.add_argument('--python', default=sys.executable)
    parser.add_argument('--chromium', default='/usr/bin/chromium')
    run(parser.parse_args())
