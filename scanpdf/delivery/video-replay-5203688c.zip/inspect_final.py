"""Sample frames from the actual encoded delivery, and write the exact chapter times."""
import argparse
from io import BytesIO
import json
from pathlib import Path
import subprocess

from PIL import Image, ImageDraw


def timecode(seconds):
    stamp = int(seconds)
    return f'{stamp // 60:02d}:{stamp % 60:02d}'


def inspect(directory):
    metadata = json.loads((directory / 'technical-check.json').read_text())
    video = directory / metadata['file']
    columns, framew, frameh, labelh = 3, 480, 270, 22
    rows = (len(metadata['chapters']) + columns - 1) // columns
    canvas = Image.new('RGB', (framew * columns, rows * (frameh + labelh)), (230, 238, 233))
    draw = ImageDraw.Draw(canvas)
    bullets = ['# 成片时间码', '', f'版本 `{metadata["frozen_sha"]}` · {metadata["duration_seconds"]:.3f} 秒', '']
    for index, chapter in enumerate(metadata['chapters']):
        offset = chapter['start'] + chapter['seconds'] * .83
        frame = subprocess.check_output(['ffmpeg','-hide_banner','-loglevel','error','-ss',f'{offset:.3f}',
                                        '-i',str(video),'-frames:v','1','-vf',f'scale={framew}:{frameh}',
                                        '-f','image2pipe','-vcodec','png','-'])
        image = Image.open(BytesIO(frame)).convert('RGB')
        assert image.size == (framew, frameh) and image.getbbox()
        x, y = (index % columns) * framew, (index // columns) * (frameh + labelh)
        canvas.paste(image, (x, y))
        draw.text((x + 7, y + frameh + 3), f"{timecode(chapter['start'])}  {chapter['scene']}", fill=(12,45,37))
        bullets.append(f"- {timecode(chapter['start'])}　{chapter['title']}")
    canvas.save(directory / 'playback-contact-sheet.png')
    (directory / '成片时间码.md').write_text('\n'.join(bullets) + '\n')


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('directory', type=Path)
    inspect(p.parse_args().directory)
