"""Use the same-SHA bilingual take while preserving the original 11 raw captures."""
import argparse
import json
import os
from pathlib import Path


def assemble(raw, bilingual, out):
    proof = json.loads((raw / 'replay-proof.json').read_text())
    chosen = json.loads((bilingual / 'proof.json').read_text())
    assert proof['archived_revision'] == chosen['revision']
    assert len(proof['scenes']) == 11
    assert chosen['source_sha256'] == proof['corpus_sha256']['1706.03762v1.pdf']
    assert chosen['protected_term'] in chosen['translation']
    out.mkdir(parents=True, exist_ok=False)
    for name in proof['scenes']:
        origin = bilingual if name == '08-bilingual' else raw
        os.link(origin / f'{name}.webm', out / f'{name}.webm')
        os.link(origin / f'{name}.png', out / f'{name}.png')
    proof['bilingual'] = chosen
    proof['scenes']['08-bilingual'] = {'actions': chosen['actions'], 'separate_same_sha_take': True}
    (out / 'replay-proof.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('raw', type=Path)
    p.add_argument('bilingual', type=Path)
    p.add_argument('out', type=Path)
    a = p.parse_args()
    assemble(a.raw, a.bilingual, a.out)
