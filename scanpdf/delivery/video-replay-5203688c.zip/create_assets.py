"""Create original fictional judging fixtures without modifying the application repository."""
from pathlib import Path
import hashlib
import json
import pymupdf

OUT = Path(__file__).resolve().parent / 'assets'
REPORT = OUT / 'Dusk-Marsh-Acoustic-Survey.pdf'
TRIALS = OUT / 'fictional-trial-latency.csv'


def create():
    OUT.mkdir(exist_ok=True)
    with pymupdf.open() as document:
        document.set_metadata({'title': 'Dusk Marsh Acoustic Monitoring Survey',
                               'subject': 'Original fictional evidence-tracing demonstration fixture',
                               'author': 'Evidence Desk demo fixture'})
        page = document.new_page(width=540, height=680)
        page.insert_text((40, 58), 'Dusk Marsh Acoustic Monitoring Survey', fontsize=20)
        page.insert_text((40, 86), 'Fictional sample for an offline product demonstration', fontsize=10)
        for y, title, paragraph in (
            (147, 'Abstract', 'We summarize fictional instrument placement and validation scores from two boardwalks.'),
            (245, '1. Deployment', 'During the spring survey, the team installed 17 waterproof acoustic recorders on the eastern boardwalk.'),
            (336, '2. Other equipment', 'The western boardwalk had 11 battery-powered wildlife cameras. All 11 cameras recorded dusk activity.'),
            (442, '3. Data limits', 'This fixture includes deployment counts and validation scores. The report does not disclose procurement prices.'),
        ):
            page.insert_text((40, y), title, fontsize=14)
            page.insert_textbox((40, y + 16, 500, y + 82), paragraph, fontsize=12)
        page.insert_text((40, 636), '1    Original fictional fixture. No real field measurements.', fontsize=9)
        page = document.new_page(width=540, height=680)
        page.insert_text((40, 51), '4. Validation results', fontsize=18)
        page.insert_text((42, 136), 'Table 2.4: Validation results for the two boardwalks', fontsize=13)
        for x in (40, 200, 340, 500):
            page.draw_line((x, 153), (x, 258), width=.85)
        for y in (153, 188, 223, 258):
            page.draw_line((40, y), (500, y), width=.85)
        for row, y in zip((('Boardwalk', 'F1', 'Accuracy'), ('East', '78.6', '82.1'), ('West', '84.3', '88.2')),
                          (177, 212, 247)):
            for x, value in zip((52, 214, 355), row):
                page.insert_text((x, y), value, fontsize=12)
        page.insert_text((40, 636), '2    Original fictional fixture. No real benchmark results.', fontsize=9)
        document.save(REPORT, no_new_id=True, deflate=True, garbage=4)
    TRIALS.write_text('trial,latency_ms\nA,14\nB,10\nC,\nD,12\nE,9\n', encoding='utf-8')
    return {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in (REPORT, TRIALS)}


if __name__ == '__main__':
    print(json.dumps(create(), indent=2))
