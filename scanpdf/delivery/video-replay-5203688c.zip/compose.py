"""Join real Chromium video clips and Kokoro narration into an auditable 1080p MP4."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess


ASS_HEADER = '''[Script Info]
ScriptType: v4.00+
PlayResX: 1920
PlayResY: 1080
YCbCr Matrix: TV.709
[V4+ Styles]
Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding
Style: Caption,Noto Sans CJK SC,36,&H00FFFFFF,&H00FFFFFF,&H0021302C,&H0021302C,0,0,0,0,100,100,0,0,3,8,0,2,80,80,25,1
Style: Chapter,Noto Sans CJK SC,28,&H00FFFFFF,&H00FFFFFF,&H0036554A,&H0036554A,-1,0,0,0,100,100,0,0,3,8,0,7,26,26,20,1
[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
'''


def run(*arguments, cwd=None):
    return subprocess.run([str(a) for a in arguments], cwd=cwd, check=True, text=True,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE)


def probe(path):
    return json.loads(run('ffprobe','-v','error','-show_format','-show_streams','-of','json',path).stdout)


def ass_time(seconds):
    ticks = round(seconds * 100)
    return f'{ticks//360000}:{ticks//6000%60:02d}:{ticks//100%60:02d}.{ticks%100:02d}'


def caption_wrap(text):
    groups, current = [], ''
    for part in re.findall(r'[^，。！？、]+[，。！？、]?|[，。！？、]', text):
        if current and len(current + part) > 36:
            groups.append(current)
            current = ''
        current += part
    if current:
        groups.append(current)
    return r'\N'.join(groups)


def dialog(start, end, style, text):
    return f'Dialogue: 0,{ass_time(start)},{ass_time(end)},{style},,0,0,0,,{text}\n'


def encode_scene(chapter, raw, narration, out, preview):
    source = raw / f"{chapter['id']}.webm"
    duration = float(probe(source)['format']['duration'])
    if preview:
        length = min(15.0, duration)
    else:
        if duration < chapter['seconds']:
            raise ValueError(f"Browser clip shorter than its narration: {chapter['id']}")
        length = max(duration, chapter['seconds'] + 1.2)
    caption = out / f"{chapter['id']}.ass"
    name = ('试录 · ' if preview else '') + chapter['title']
    labels = dialog(0, min(length, 8.0) if chapter['id'] == '01-intro' else min(length, 5.0), 'Chapter', name)
    if chapter['id'] == '01-intro' and not preview and length > 15:
        labels += dialog(8, 15, 'Chapter', '本机运行｜E5 检索 · MobileBERT 抽取 · OPUS-MT 翻译')
    if chapter['id'] == '08-bilingual' and not preview and length > 12:
        labels += dialog(5, 12, 'Chapter', '机器译文｜保留指定术语，学术表述需对照原文')
    for cue in chapter['cues']:
        start, end = cue['start'] + .45, min(length, cue['end'] + .45)
        if end > start:
            labels += dialog(start, end, 'Caption', caption_wrap(cue['text']))
    caption.write_text(ASS_HEADER + labels)
    part = out / f"{chapter['id']}.mp4"
    voice = narration / f"{chapter['id']}.wav"
    run('ffmpeg','-n','-hide_banner','-loglevel','error','-i',source,'-i',voice,
        '-vf',f'fps=25,ass={caption.name},tpad=stop_mode=clone:stop_duration=1.2',
        '-af','adelay=450,apad','-t',f'{length:.3f}','-c:v','libx264','-pix_fmt','yuv420p','-threads','2',
        '-preset','veryfast','-crf','20','-c:a','aac','-b:a','128k','-ar','44100',part, cwd=out)
    return part


def compose(raw, narration, out, preview):
    proof = json.loads((raw / 'replay-proof.json').read_text())
    if not preview and (not proof.get('archived_revision') or len(proof.get('scenes', {})) != 11):
        raise ValueError('Final assembly requires the complete, successful, frozen-SHA recordings.')
    if not preview and (proof.get('positive', {}).get('answer_method') != 'local_extractive'
                        or 'multilingual-e5-small' not in proof.get('positive', {}).get('retrieval', {}).get('methods', [])
                        or len(proof.get('bilingual', {}).get('translation', '')) < 60):
        raise ValueError('The label in the narration must match the actual local runtime results.')
    out.mkdir(parents=True, exist_ok=False)
    chapters = json.loads((narration / 'voice-manifest.json').read_text())
    if preview:
        chapters = [chapter for chapter in chapters if chapter['id'] == preview]
    if len(chapters) != (1 if preview else 11):
        raise ValueError('Narration scope differs from the requested cut.')
    paths = [encode_scene(chapter, raw, narration, out, preview) for chapter in chapters]
    timing = []
    elapsed = 0.0
    for chapter, part in zip(chapters, paths):
        duration = float(probe(part)['format']['duration'])
        timing.append({'scene': chapter['id'], 'title': chapter['title'], 'start': elapsed, 'seconds': duration})
        elapsed += duration
    concat = out / 'segments.ffconcat'
    concat.write_text('ffconcat version 1.0\n' + ''.join(f'file {path.name}\n' for path in paths))
    basename = 'evidence-desk-rehearsal' if preview else f"evidence-desk-mandarin-1080p-{proof['archived_revision'][:8]}"
    target = out / f'{basename}.mp4'
    run('ffmpeg','-n','-hide_banner','-loglevel','error','-f','concat','-safe','1','-i',concat,
        '-c:v','copy','-af','loudnorm=I=-16:TP=-1.5:LRA=11','-c:a','aac','-ar','44100',
        '-b:a','128k','-movflags','+faststart',target)
    inspected = probe(target)
    duration = float(inspected['format']['duration'])
    video, = [stream for stream in inspected['streams'] if stream['codec_type'] == 'video']
    audio, = [stream for stream in inspected['streams'] if stream['codec_type'] == 'audio']
    assert (video['width'],video['height'],video['codec_name'],audio['codec_name']) == (1920,1080,'h264','aac')
    assert preview or 300 <= duration <= 480, duration
    run('ffmpeg','-hide_banner','-loglevel','error','-xerror','-i',target,'-f','null','-')
    volume = run('ffmpeg','-nostats','-hide_banner','-i',target,'-af','ebur128=peak=true','-vn','-f','null','-').stderr
    with target.open('rb') as file:
        sha = hashlib.file_digest(file, 'sha256').hexdigest()
    report = {'sha256':sha,'file':target.name,'duration_seconds':duration,'width':1920,'height':1080,
              'video_codec':'h264','audio_codec':'aac','fully_decoded':True,
              'audio_analysis':volume.rsplit('Summary:',1)[-1].split('[out#',1)[0].strip(),
              'frozen_sha':proof.get('archived_revision'),'chapters':timing}
    (out / 'technical-check.json').write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--raw', type=Path, required=True)
    parser.add_argument('--narration', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--preview', help='Make a prominently labeled short test using only the specified chapter')
    args = parser.parse_args()
    compose(args.raw.resolve(), args.narration.resolve(), args.out.resolve(), args.preview)
