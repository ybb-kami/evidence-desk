#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
out=${1:-build}
mkdir -p "$out"
for pass in 1 2; do
  xelatex -no-shell-escape -halt-on-error -interaction=nonstopmode -output-directory="$out" main.tex > "$out/xelatex-$pass.log"
done
if rg -n 'Missing character|Overfull \\[hv]box|LaTeX Warning:.*undefined' "$out/main.log"; then
  exit 2
fi
printf '%s\n' "$out/main.pdf"
