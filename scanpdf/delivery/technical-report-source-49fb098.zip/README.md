# 证据台技术说明 · XeLaTeX 源码

主文件为 `main.tex`，版式与标题信息在 `venue.tex`，冻结版本在 `results.tex`。正文按功能、评价和复现入口分文件。只附实际画面和允许复核的汇总，题目原件、模型权重及封存题的题文与逐题原始响应留在各自来源。

## 构建

需要 XeLaTeX、TeX Live 的 `fontspec`、`geometry`、`booktabs`、`tabularx`、`amsmath`、`graphics`、`caption`、`titlesec`、`hyperref`、`fancyhdr`、`needspace`、PGF/TikZ，以及 Noto Serif CJK SC、Noto Sans CJK SC、DejaVu Sans Mono、ripgrep。采用自编 A4 技术说明版式。公开赛题附件没有可核实的 LaTeX 类。

```sh
bash build.sh
pdfinfo build/main.pdf
pdftotext -layout build/main.pdf build/main.txt
sha256sum -c evidence/figures.sha256
```

保留本源码、已核验 PDF 与实际素材记录。新增数据先核对其版本、分子和分母，再编辑对应段落。图版素材完整保留原像素，LaTeX 只缩放页面显示。

## 源与评测身份

- 个人赛参赛署名为袁瑞，青海大学，报名系统队伍名为 26CZB0001406。本版另建文件，沿用锁定的参赛信息。独立的 [AI 协同与 Prompt 审计](https://github.com/ybb-kami/evidence-desk/blob/c94c6285d7a1a4e9764644dd35ca6469b3378efe/scanpdf/delivery/AI-COLLABORATION.md) 没有改写。
- 赛题公开镜像固定在 `52d11950da4f3da1dcb830d6212665eb89c0394f`，七页题面 SHA‑256 为 `58b406ac67aa2b53ff013ae9cac1920c8579ebdd0d3134afe4c06524f77862f6`。复核了技术材料、视频、在线演示和统一提交条款。评分章节与参赛者后来转交细则版本有差异，正文采用后者并注明来源。[赛题镜像](https://github.com/CuiMiles/ResearchTrace/blob/52d11950da4f3da1dcb830d6212665eb89c0394f/evals/pdfs/科研小助手/科研小助手Agent-AI大模型.pdf)
- 五幅图版来自冻结版 `5203688cf7d8b1f3340b63eeada92167855455bc` 的真实 Chromium 实录。双语图来自同提交、同原件的录制补拍，术语保留与同步操作均有回执。截图与模型日志未用于证明人工译文质量。[实录证明](https://github.com/ybb-kami/evidence-desk/blob/c94c6285d7a1a4e9764644dd35ca6469b3378efe/scanpdf/delivery/video-proof-5203688c.json)
- `evidence/scanned-figures.json` 对应另外三幅程序直接截取的图版，保存原 PDF 字节指纹、物理页、图框与图注。Attention 两幅取公告扫描件，FlashAttention 先转成无字层逐页代理。`evidence/scanned-figures-browser.json` 保存工作台复跑和旧锚点升级的机器回执。引用原论文用于验收对读。[Vaswani 等](https://arxiv.org/abs/1706.03762v1) · [Dao 等](https://arxiv.org/abs/2205.14135v2)
- `evidence/first-holdout-aggregate.json` 记录 `5203688` 的原 30 道封存题汇总、拒答分类、生成状态、引文核验与耗时。`evidence/paired-49fb098-aggregate.json` 记录同一批题在 `c94c628` 和 `49fb098` 的配对统计。报告注明真实工具调用的早期候选和新的评委配置。[早期真实工具调用回执](https://github.com/ybb-kami/evidence-desk/blob/c94c6285d7a1a4e9764644dd35ca6469b3378efe/scanpdf/acceptance/results/copilot-local-browser.json)
